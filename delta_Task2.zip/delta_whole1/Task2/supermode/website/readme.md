The site uses node
nodemon to stop refreshing constantly
thing to run datab.py has the code to enter the databse into the system it creates accounts/databases for each student , in HAD all student details are present in GarnetA databse only GarnetA student details are present.
When website runs , and user enters username and passwd the database is selected and details are shown.

<?php
echo "hello world";